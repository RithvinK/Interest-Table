package Model;

public class Interest {
		
	/* Simple Interest Amount Formula */
	public double simpleInterestAmount(int principal, double rate, int years) {
		return principal + (principal * (rate/100) * years);
	}
	
	/* Compound Interest Amount Formula */	
	public double compoundInterestAmount(int principal, double rate, int years){
		return principal * Math.pow(1+rate/100, years);
	}

}
