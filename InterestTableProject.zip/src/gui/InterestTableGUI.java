/* Jongwook Lee 117981704
Rithvin Koneru 117853100
 */

package gui;

import Model.Interest;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Slider;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;


public class InterestTableGUI extends Application {

	private TextField principal, rate;
	private Slider yearsSlider;
	private TextArea output;

	public void start(Stage primaryStage) {
		int sceneWidth = 425, sceneHeight = 300;
		int verSpaceBetweenNodes = 8, horSpaceBetweenNodes = 8;
		int paneBorderTop = 20, paneBorderRight = 20;
		int paneBorderBottom = 20, paneBorderLeft = 20;
		GridPane totalPane = new GridPane();
		GridPane optionPane = new GridPane();

		/* Setting characteristics of bottom values pane */
		optionPane.setHgap(horSpaceBetweenNodes);
		optionPane.setVgap(verSpaceBetweenNodes);
		optionPane.setPadding(new Insets(paneBorderTop, paneBorderRight, 
				paneBorderBottom, paneBorderLeft));

		/* Principal */
		GridPane valPane = new GridPane();
		valPane.setHgap(horSpaceBetweenNodes);
		Label principalLabel = new Label("Principal:");
		principal = new TextField();
		principal.setPrefWidth(100);
		optionPane.addRow(0, principalLabel, principal);

		/* Rate */
		Label rateLabel = new Label("Rate(Percentage):");
		rate = new TextField();
		rate.setPrefWidth(100);
		valPane.addRow(0, principalLabel, principal, rateLabel, rate);
		valPane.alignmentProperty();
		optionPane.addRow(0, valPane);

		/* Year Slider */
		FlowPane sliderPane = new FlowPane();
		Label yearLabel = new Label("Number of Years:");
		Slider yearSlider = new Slider();
		yearSlider.setMin(1);
		yearSlider.setMax(25);
		yearSlider.setValue(1);
		yearSlider.setMajorTickUnit(4);
		yearSlider.setMinorTickCount(3);
		yearSlider.setShowTickMarks(true);
		yearSlider.setShowTickLabels(true);
		yearSlider.setPrefWidth(250);
		sliderPane.getChildren().addAll(yearLabel, yearSlider);
		optionPane.addRow(1, sliderPane);
		sliderPane.setAlignment(Pos.CENTER);
		yearsSlider = yearSlider;


		/* Interest Buttons */
		FlowPane buttonPane = new FlowPane();
		buttonPane.setHgap(horSpaceBetweenNodes);
		Button buttonOne = new Button("SimpleInterest");
		Button buttonTwo = new Button("CompoundInterest");
		Button buttonThree = new Button("BothInterests");
		buttonPane.getChildren().addAll(buttonOne, buttonTwo, buttonThree);
		buttonPane.setAlignment(Pos.CENTER);
		optionPane.addRow(2, buttonPane);


		/* Top Stage */
		output = new TextArea();
		output.setEditable(false);
		output.setWrapText(true);

		/* Scrollwheel */		
		ScrollPane s = new ScrollPane(output);


		/* Using anonymous inner class */
		buttonOne.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				if (principal.getText().isEmpty() || rate.getText().isEmpty()) {
					return;
				}
				
				int years = (int) yearSlider.getValue();
				Interest interest = new Interest();
				int principalVal = Integer.parseInt(principal.getText());
				double rateVal = Double.parseDouble(rate.getText());
				
				String total = "Principal: " + "$" + String.format("%,.2f", 
				Double.parseDouble(principal.getText())) + ", Rate: " + rateVal
				+ "\n";
				total += "Year, Simple Interest Amount\n";

				for(int year = 1; year <= years; year++) {
					total += year + "-->" + "$" + String.format("%,.2f", 
							interest.simpleInterestAmount(principalVal, rateVal, 
									year)) + "\n";
				}
				output.setText(total);
			}
		});
		
		Handler buttonHandler = new Handler();
		buttonTwo.setOnAction(buttonHandler);

		/* Using Lambda expression */
		buttonThree.setOnAction(e -> {
			if (principal.getText().isEmpty() || rate.getText().isEmpty()) {
				return;
			}
			int years = (int) yearSlider.getValue();
			Interest interest = new Interest();
			int principalVal = Integer.parseInt(principal.getText());
			double rateVal = Double.parseDouble(rate.getText());
			String total = "Principal: " + "$" + String.format("%,.2f", 
				Double.parseDouble(principal.getText())) + ", Rate: " + rateVal
				+ "\n";
			total += "Year, Simple Interest Amount, Compound Interest Amount\n";

			for (int year = 1; year <= years; year++) {
				total += year + "-->" + "$" + 
						String.format("%,.2f", 
								interest.simpleInterestAmount(principalVal, 
										rateVal, year)) 
				+ "-->" + "$" + String.format("%,.2f", 
						interest.compoundInterestAmount(principalVal, rateVal, 
								year))
				+ "\n";
			}
			output.setText(total);

		});


		/* Full Stage display */
		totalPane.addRow(0, s);
		totalPane.addRow(1, optionPane);
		Scene scene = new Scene(totalPane, sceneWidth, sceneHeight);
		primaryStage.setTitle("Interest Table Calculator");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	public Slider getYears() {
		return this.yearsSlider;
	}
	

	/* Using non-anonymous inner class */
	private class Handler implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent e) {
			if (principal.getText().isEmpty() || rate.getText().isEmpty()) {
				return;
			}
			int years = (int) getYears().getValue();
			Interest interest = new Interest();
			int principalVal = Integer.parseInt(principal.getText());
			double rateVal = Double.parseDouble(rate.getText());
			String total = "Principal: " + "$" + String.format("%,.2f", 
				Double.parseDouble(principal.getText())) + ", Rate: " + rateVal
				+ "\n";
			total += "Year, Compound Interest Amount\n";

			for(int year = 1; year <= years; year++) {
				total += year + "-->" + "$" + String.format("%,.2f", 
						interest.compoundInterestAmount(principalVal, rateVal, 
								year)) + "\n";
			}
			output.setText(total);

		}
	}

	public static void main(String[] args) {
		Application.launch(args);
	}
}
